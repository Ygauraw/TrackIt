<?php

$time = $_REQUEST["time"];
$username = $_REQUEST["username"];
$password = $_REQUEST["password"];

$response["success"] = 0;
$response["uid"] = 0;
$response["username"] = $username;
$response["password"] = $password;


$db_name = "SATYA";
$con = mysql_connect("localhost", "ENTER_VALID_USER_NAME", "ENTER_VALID_PASSWORD");
if(!$con)
{
	$response["message"] = "mysql_connect error: " . mysql_error();
} else {

	$db_selected = mysql_select_db($db_name,$con);

	if(!$db_selected)
	{
		$response["message"] = "mysql_select_db error: " . mysql_error();
	} else {

		$user_table_name = "userbase";

		if(table_exists("$user_table_name"))
		{
			$sql = "select uid,userfullname from userbase where username='$username' and userpass='$password'";
			$list = mysql_query($sql, $con);
			if(!$list) {
				 $response["message"] = "Error in finding all other users table (near by user loctions):". $sql . mysql_error();
			} else {
				$num_rows = mysql_numrows($list);
				if($num_rows > 0) {
				$response["success"] = 1;
				$response["uid"] = mysql_result($list,0,"uid");
				$response["userfullname"] = mysql_result($list, 0, "userfullname");
				$response["num_res"] = $num_rows;
				} else {
				$response["message"] = "No results found";
				}
				$response["sql"] = $sql;
			}
		}
	}
	mysql_close($con);
}

echo json_encode($response);

function table_exists($tablename, $database = false) {

    if(!$database) {
        $res = mysql_query("SELECT DATABASE()");
        $database = mysql_result($res, 0);
    }

    $res = mysql_query("
	SELECT COUNT(*) AS count
        FROM information_schema.tables
        WHERE table_schema = '$database'
        AND table_name = '$tablename'
	");

    return mysql_result($res, 0) == 1;
}

?>
