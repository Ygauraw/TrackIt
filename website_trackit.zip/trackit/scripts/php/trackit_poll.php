<?php
$ROUTE_PREFIX = "route_";
$ROUTE_OVERLAY_PREFIX = "overlay_";
$uid = $_REQUEST["uid"];
$time = $_REQUEST["time"];
$requestroute = $_REQUEST["route_req"];

$response = array();
$response["success"] = 0;
$response["message"] = "ok";
$response["requesturl"] = $_REQUEST;
//$response["Access-Control-Allow-Origin"]="*";

$vehicales = array();

$db_name = "SATYA";
$con = mysql_connect("localhost", "ENTER_VALID_USER_NAME", "ENTER_VALID_PASSWORD");
if(!$con)
{
	$msg = 'Could not connect: ' . mysql_error();
	die_after_updating_client($msg);
}

$db_selected = mysql_select_db($db_name,$con);

if(!$db_selected)
{
	$msg = 'Can\'t use ' . $db_name. ' : ' . mysql_error();
	die_after_updating_client($msg);
}

$route_overlay = $ROUTE_OVERLAY_PREFIX.$uid;
if($requestroute && table_exists("$route_overlay"))
{

	try{
		$sql = "select id,lat,lng from $route_overlay order by id";
		$result = mysql_query($sql, $con);
		$num = mysql_numrows($result);
		$response["num"] = $num;
		$j = 0;
		$all_routes = array();
		$route = array();
		$overlay_points = array();
		while($j < $num)
		{
			$point = array();
			$filedlat = mysql_result($result, $j, "lat");
			$fieldlng = mysql_result($result, $j, "lng");
			$point["lat"] = $filedlat;
			$point["lng"] = $fieldlng;
			array_push($overlay_points,$point);
			$j = $j + 1;
		}
		$route["uid"] = $uid;
		$route["points"] = $overlay_points;
		array_push($all_routes, $route);
		$response["routes"] = $all_routes;

	}catch (Exception $e) {
		echo $mysql_error() . $sql;
	}
}


$route_table = $ROUTE_PREFIX. $uid;
if(!table_exists("$route_table")) {
	$response["message"] = "Sorry none of your friend is TrackinIt !";
	$response["success"] = -1;
} else {

	$sql = "SELECT DISTINCT TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$db_name' and TABLE_NAME like '$route_table%'";

	$list = mysql_query($sql, $con);
	if(!$list) {
		$msg = 'Error occured: ' . mysql_error() . $sql;
		die_after_updating_client($msg);
	}
	$i = 0;
	$idarray = array();
	$timearray = array();
	$latarray = array();
	$longarray = array();
	$bearing = array();
	$speed = array();
	$count = 0;

	$deltatime = (time() - 120 ) * 1000;

	while($i < mysql_num_rows($list))
	{
		$tb_names[$i] = mysql_tablename($list,$i);
		//$sql = "SELECT * FROM $tb_names[$i] where timestamp > $deltatime order by timestamp desc limit 5";
		$sql = "SELECT * FROM $tb_names[$i] order by timestamp desc limit 1";
		//echo "Table [". $i."] ".$tb_names[$i] . "|". $sql . "\n";
		$result = mysql_query($sql, $con);
		$num = mysql_numrows($result);
		$j = 0;
		while($j < $num)
		{
			try {
			$fieldtime = mysql_result($result, $j, "timestamp");
			$fieldlatitude = mysql_result($result, $j, "latitude");
			$fieldlongitude = mysql_result($result, $j, "longitude");
			$fieldbearing = mysql_result($result, $j, "bearing");
			$fieldspeed = mysql_result($result, $j, "speed");
			#$fielduserid = get_userid($tb_names[$i], $con);
			$timearray[] = $fieldtime;
			$idarray[] = $fielduserid;
			$latarray[] = $fieldlatitude;
			$longarray[] = $fieldlongitude;
			$bearingarray[] = $fieldbearing;
			$speedarray[] = $fieldspeed;

			} catch (Exception $e) {
				//echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
			$count ++;
			$j++;
		}
		$i++;
	}

	for ($i = 0; $i < $count; $i++)
	{
		$msg = "Lat: " . $latarray[$i] . " Lng: " . $longarray[$i] . " Bearing: " . $bearingarray[$i] . " Speed: " . $speedarray[$i];
		#echo $msg . "\n";
		$veh = array();
		$veh["uid"] =  $uid;
		$veh["registration"] = $uid . '-AA-'. $i;
		$veh["timestamp"] = $timearray[$i];
		$veh["latitude"] = $latarray[$i];
		$veh["longitude"] = $longarray[$i];
		$veh["bearing"] = $bearingarray[$i];
		$veh["speed"] = $speedarray[$i];

		array_push($vehicales, $veh);
	}
	$response["vehicales"] = $vehicales;
	if($count)
		$response["success"] = 1;
	else
		$response["message"] = "Information is unavailable";
}
mysql_close($con);


function table_exists($tablename, $database = false) {

    if(!$database) {
        $res = mysql_query("SELECT DATABASE()");
        $database = mysql_result($res, 0);
    }

    $res = mysql_query("
	SELECT COUNT(*) AS count
        FROM information_schema.tables
        WHERE table_schema = '$database'
        AND table_name = '$tablename'
	");

    return mysql_result($res, 0) == 1;
}

function die_after_updating_client($msg) {
	echo json_encode($response);
	if ($GET['callback'] != '') $response = $GET['callback']."( $response )";
	die($msg);
}
// assume $json holds the JSON response
if ($GET['callback'] != '') $response = $GET['callback']."( $response )";

echo json_encode($response);
?>
