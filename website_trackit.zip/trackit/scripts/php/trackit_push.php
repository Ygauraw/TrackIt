<?php
$ROUTE_PREFIX = "route_";

$uid = $_REQUEST["uid"];
$timestamp = $_REQUEST["timestamp"];
$latitude = $_REQUEST["latitude"];
$longitude = $_REQUEST["longitude"];
$bearing = $_REQUEST["bearing"];
$speed = $_REQUEST["speed"];

$response = array();
$response["success"] = 0;
$response["message"] = "ok";
//$response["request"] = $_REQUEST;

$user = array();

$db_name = "SATYA";
$con = mysql_connect("localhost", "ENTER_VALID_USER_NAME", "ENTER_VALID_PASSWORD");
if(!$con)
{
	die('Could not connect: ' . mysql_error());
}

$db_selected = mysql_select_db($db_name,$con);

if(!$db_selected)
{
	die('Can\'t use ' . $db_name. ' : ' . mysql_error());
}

$route_table_name = $ROUTE_PREFIX. $uid;
if(!table_exists("$route_table_name"))
{
	$sql = "CREATE TABLE $route_table_name (
			timestamp long,
			latitude DECIMAL(14,10), longitude DECIMAL(14,10),
			bearing DECIMAL(14,10), speed DECIMAL(14,10),
			unread_msgs bool
		)";

	$result = mysql_query($sql, $con);
	if(!$result)
	{
		$msg = 'Invalid query: ' . mysql_error() . $sql . "\n";
		//echo $msg . "\n";
	}
}


$sql = "INSERT INTO $route_table_name (timestamp, latitude, longitude, bearing, speed, unread_msgs) VALUES ('$timestamp', '$latitude', '$longitude', '$bearing', '$speed', '1')";

$result = mysql_query($sql, $con);

if(!$result) {
	//echo "Error in inserting elements to the table: $route_table_name " . mysql_error() . "\n";
	$msg = 'Error occured: ' . mysql_error() . $sql."\n";
	$response["message"] = $msg;
} else {
	$response["success"] = 1;
}

mysql_close($con);

echo json_encode($response);

function table_exists($tablename, $database = false) {
    if(!$database) {
        $res = mysql_query("SELECT DATABASE()");
        $database = mysql_result($res, 0);
    }

    $res = mysql_query("
	SELECT COUNT(*) AS count
        FROM information_schema.tables
        WHERE table_schema = '$database'
        AND table_name = '$tablename'
	");

    return mysql_result($res, 0) == 1;
}

?>
