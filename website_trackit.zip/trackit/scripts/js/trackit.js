function showInfoWindow() {
	var infowindow = new google.maps.InfoWindow({
		map: map,
		position: p1,
		content:
			'<h1>Current Geolocation!</h1>' +
			'<h2>Latitude: ' + position.coords.latitude + '</h2>' +
			'<h2>Longitude: ' + position.coords.longitude + '</h2>'
	});
}

var markerHolder = new Array();
var routeOverlayHolder = new Array();

function initialize() {
	var mapOptions = {
		zoom: 13,
		center: new google.maps.LatLng(39.2607704,-76.7008031),
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var map = new google.maps.Map(document.getElementById('google_canvas'),mapOptions);
	
	/*
	google.maps.event.addListener(map, 'click', function(e) {
		placeMarker(e.latLng, map);
	});
	*/

	draw_route_overlay(map,routeOverlayHolder,35);

	update_marker_location(map,markerHolder,35);
}

function placeMarker(position, map) {
	var marker = new google.maps.Marker({
		position: position,
		map: map
	});
	map.panTo(position);
}
