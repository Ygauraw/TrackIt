function update_marker_location(mMap,markerHolder,route_id) {

		var bounds2 = new google.maps.LatLngBounds();
		var xmlhttp;
		xmlhttp=((window.XMLHttpRequest)?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP"));
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200){
				res=JSON.parse(xmlhttp.responseText);
				//console.debug(xmlhttp.responseText);
				//draw new markers
				for(i=0;i<res.vehicales.length;i++){
					var cur_uid = res.vehicales[i].uid;
					var point=new google.maps.LatLng(res.vehicales[i].latitude,res.vehicales[i].longitude);
					bounds2.extend(point);
					if(typeof(markerHolder[cur_uid]) != 'undefined') {
						markerHolder[cur_uid].setPosition(point);
					} else {
						var marker = new google.maps.Marker({position: point,map: mMap});
						markerHolder[cur_uid]= marker;
					}
				}
				window.setTimeout(update_marker_location(mMap,markerHolder,route_id),5000*10);
			}
		}
		var Server = "http://mpss.csce.uark.edu/~satya1";
		var PollURL = "/trackit/scripts/php/trackit_poll.php?uid=" + route_id;
		xmlhttp.open("POST",Server + PollURL,true);
		xmlhttp.send();

}
