function draw_route_overlay(mMap,polyLineHolder,route_id) {

		var bounds2 = new google.maps.LatLngBounds();
		var xmlhttp;
		xmlhttp=((window.XMLHttpRequest)?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP"));
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200){
				res=JSON.parse(xmlhttp.responseText);
				if(res.success > 0)
				{
					//draw new markers
					for(i=0;i<res.routes.length;i++){
						var cur_uid = res.routes[i].uid;
						var cur_uid_points = res.routes[i].points;
						
						if(typeof(polyLineHolder[cur_uid]) != 'undefined') {
							for(elem in  polyLineHolder[cur_uid].points) {
								elem = null;
							}
							polyLineHolder[cur_uid][points] = undefined;
							polyLineHolder[cur_uid][line].remove(mMap);
						}
						
						var points_array = new Array();
						for(j=0;j< cur_uid_points.length; j++)
						{
							var point=new google.maps.LatLng(cur_uid_points[j].lat,cur_uid_points[j].lng);
							bounds2.extend(point);
							points_array.push(point);
						}
						
						var iconsetngs = {
							path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
							strokeColor: '#FF0000'
						};

						var routePath = new google.maps.Polyline({
							path: points_array,
							strokeColor: '#333',
							strokeOpacity: 0.8,
							strokeWeight: 3
							//icons: [{icon: iconsetngs, offset: '100%'}]
						});
						routePath.setMap(mMap);
						polyLineHolder[cur_uid] = new Object();
						polyLineHolder[cur_uid].line = routePath;
						polyLineHolder[cur_uid].points = points_array;

						//console.debug(polyLineHolder);
					}
				}
			}
		}
		var Server = "http://mpss.csce.uark.edu/~satya1";
		var PollURL = "/trackit/scripts/php/trackit_poll.php?uid=" + route_id + "&route_req=1";

		xmlhttp.open("POST",Server + PollURL,true);
		xmlhttp.send();
}
