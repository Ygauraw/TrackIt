<?php

$db_name = "SATYA";
$con = mysql_connect("localhost", "crowdsource", "crowdsource123~");
if(!$con)
{
        die('Could not connect: ' . mysql_error());
}

$db_selected = mysql_select_db($db_name,$con);

if(!$db_selected)
{
        die('Can\'t use ' . $db_name. ' : ' . mysql_error());
}



// get contents of a file into a string
	$sql = "select * from overlay_35";
	$result = mysql_query($sql, $con);
	echo $result[0];

mysql_close($con);

?>
