<?php

$db_name = "SATYA";
$con = mysql_connect("localhost", "crowdsource", "crowdsource123~");
if(!$con)
{
        die('Could not connect: ' . mysql_error());
}

$db_selected = mysql_select_db($db_name,$con);

if(!$db_selected)
{
        die('Can\'t use ' . $db_name. ' : ' . mysql_error());
}



// get contents of a file into a string
$filename = "./overlay_1.txt";
$fp = fopen( $filename, "r" ) or die("Couldn't open $filename");
while ( ! feof( $fp ) ) {
   $line = fgets( $fp, 1024 );
	$sql = rtrim($line, " \n");
	$result = mysql_query($sql, $con);
	if(!$result)
	{
	        echo "Error in inserting elements to the table: $user_table_name " . mysql_error() . "\n";
	}
}
mysql_close($con);

?>
